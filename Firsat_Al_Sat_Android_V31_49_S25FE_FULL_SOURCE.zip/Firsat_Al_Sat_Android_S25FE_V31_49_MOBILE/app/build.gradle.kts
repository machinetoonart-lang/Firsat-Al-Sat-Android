plugins {
    id("com.android.application")
}

android {
    namespace = "com.firsatalsat.mobile"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.firsatalsat.mobile"
        minSdk = 26
        targetSdk = 36
        versionCode = 314901
        versionName = "31.49-mobile-1"
    }

    buildFeatures {
        buildConfig = true
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
