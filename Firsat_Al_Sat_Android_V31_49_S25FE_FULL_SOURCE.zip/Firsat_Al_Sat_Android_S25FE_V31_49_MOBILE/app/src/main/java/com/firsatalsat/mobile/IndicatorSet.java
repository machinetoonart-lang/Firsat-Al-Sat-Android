package com.firsatalsat.mobile;

public final class IndicatorSet {
    public final double[] bbMid, bbUpper, bbLower;
    public final double[] macd, macdSignal, macdHist;
    public final double[] stochK, stochD;
    public final double[] superTrend;
    public final int[] superTrendDir; // +1 green/up, -1 red/down
    public final double[] volumeSma9;
    public IndicatorSet(int n) {
        bbMid=new double[n]; bbUpper=new double[n]; bbLower=new double[n];
        macd=new double[n]; macdSignal=new double[n]; macdHist=new double[n];
        stochK=new double[n]; stochD=new double[n]; superTrend=new double[n]; superTrendDir=new int[n]; volumeSma9=new double[n];
        java.util.Arrays.fill(bbMid, Double.NaN); java.util.Arrays.fill(bbUpper, Double.NaN); java.util.Arrays.fill(bbLower, Double.NaN);
        java.util.Arrays.fill(macd, Double.NaN); java.util.Arrays.fill(macdSignal, Double.NaN); java.util.Arrays.fill(macdHist, Double.NaN);
        java.util.Arrays.fill(stochK, Double.NaN); java.util.Arrays.fill(stochD, Double.NaN); java.util.Arrays.fill(superTrend, Double.NaN);
        java.util.Arrays.fill(volumeSma9, Double.NaN);
    }
}
