package com.firsatalsat.mobile;

import java.util.*;

public final class Indicators {
    private Indicators() {}

    public static IndicatorSet calculate(List<Candle> c) {
        int n=c.size(); IndicatorSet out=new IndicatorSet(n); if(n==0) return out;
        double[] close=new double[n], high=new double[n], low=new double[n], vol=new double[n];
        for(int i=0;i<n;i++){ Candle x=c.get(i); close[i]=x.close; high[i]=x.high; low[i]=x.low; vol[i]=x.volume; }
        double[] e12=ema(close,12), e26=ema(close,26);
        for(int i=0;i<n;i++) out.macd[i]=e12[i]-e26[i];
        double[] sig=ema(out.macd,9);
        for(int i=0;i<n;i++){ out.macdSignal[i]=sig[i]; out.macdHist[i]=out.macd[i]-sig[i]; }
        bollinger(close,20,2.0,out.bbMid,out.bbUpper,out.bbLower);
        stochRsi(close,14,14,3,3,out.stochK,out.stochD);
        superTrend(high,low,close,10,3.0,out.superTrend,out.superTrendDir);
        sma(vol,9,out.volumeSma9);
        return out;
    }

    static double[] ema(double[] x,int p){
        double[] y=new double[x.length]; if(x.length==0)return y; double a=2.0/(p+1.0); y[0]=x[0];
        for(int i=1;i<x.length;i++) y[i]=a*x[i]+(1-a)*y[i-1]; return y;
    }
    static void sma(double[] x,int p,double[] out){
        double sum=0; for(int i=0;i<x.length;i++){ sum+=x[i]; if(i>=p)sum-=x[i-p]; if(i>=p-1)out[i]=sum/p; }
    }
    static void bollinger(double[] x,int p,double k,double[] mid,double[] up,double[] dn){
        for(int i=p-1;i<x.length;i++){ double s=0; for(int j=i-p+1;j<=i;j++)s+=x[j]; double m=s/p, v=0; for(int j=i-p+1;j<=i;j++){double d=x[j]-m;v+=d*d;} double sd=Math.sqrt(v/p); mid[i]=m;up[i]=m+k*sd;dn[i]=m-k*sd; }
    }
    static double[] rsiWilder(double[] x,int p){
        int n=x.length; double[] r=new double[n]; Arrays.fill(r,Double.NaN); if(n<=p)return r;
        double gain=0,loss=0; for(int i=1;i<=p;i++){double d=x[i]-x[i-1]; if(d>0)gain+=d; else loss-=d;}
        gain/=p;loss/=p; r[p]=loss==0?100:100-(100/(1+gain/loss));
        for(int i=p+1;i<n;i++){double d=x[i]-x[i-1],g=Math.max(d,0),l=Math.max(-d,0);gain=(gain*(p-1)+g)/p;loss=(loss*(p-1)+l)/p;r[i]=loss==0?100:100-(100/(1+gain/loss));}return r;
    }
    static void stochRsi(double[] close,int rsiP,int stochP,int kP,int dP,double[] k,double[] d){
        double[] r=rsiWilder(close,rsiP), raw=new double[close.length]; Arrays.fill(raw,Double.NaN);
        for(int i=0;i<close.length;i++){ if(i<rsiP+stochP-1)continue; double mn=Double.POSITIVE_INFINITY,mx=Double.NEGATIVE_INFINITY; boolean ok=true; for(int j=i-stochP+1;j<=i;j++){ if(!Double.isFinite(r[j])){ok=false;break;}mn=Math.min(mn,r[j]);mx=Math.max(mx,r[j]);} if(ok)raw[i]=mx-mn<1e-12?50:100*(r[i]-mn)/(mx-mn); }
        movingAvgFinite(raw,kP,k); movingAvgFinite(k,dP,d);
    }
    static void movingAvgFinite(double[] x,int p,double[] out){
        for(int i=p-1;i<x.length;i++){ double s=0; boolean ok=true; for(int j=i-p+1;j<=i;j++){ if(!Double.isFinite(x[j])){ok=false;break;}s+=x[j];} if(ok)out[i]=s/p; }
    }
    static void superTrend(double[] h,double[] l,double[] c,int p,double mult,double[] st,int[] dir){
        int n=c.length; if(n==0)return; double[] tr=new double[n], atr=new double[n], fu=new double[n], fl=new double[n];
        tr[0]=h[0]-l[0]; for(int i=1;i<n;i++)tr[i]=Math.max(h[i]-l[i],Math.max(Math.abs(h[i]-c[i-1]),Math.abs(l[i]-c[i-1])));
        double s=0; for(int i=0;i<n;i++){ if(i<p){s+=tr[i]; if(i==p-1)atr[i]=s/p;} else atr[i]=(atr[i-1]*(p-1)+tr[i])/p; }
        Arrays.fill(fu,Double.NaN);Arrays.fill(fl,Double.NaN);Arrays.fill(st,Double.NaN);
        for(int i=p-1;i<n;i++){
            double hl=(h[i]+l[i])/2, bu=hl+mult*atr[i], bl=hl-mult*atr[i];
            if(i==p-1){fu[i]=bu;fl[i]=bl;dir[i]=c[i]>=hl?1:-1;st[i]=dir[i]>0?fl[i]:fu[i];continue;}
            fu[i]=(bu<fu[i-1]||c[i-1]>fu[i-1])?bu:fu[i-1];
            fl[i]=(bl>fl[i-1]||c[i-1]<fl[i-1])?bl:fl[i-1];
            if(dir[i-1]<0) dir[i]=c[i]>fu[i]?1:-1; else dir[i]=c[i]<fl[i]?-1:1;
            st[i]=dir[i]>0?fl[i]:fu[i];
        }
    }
}
