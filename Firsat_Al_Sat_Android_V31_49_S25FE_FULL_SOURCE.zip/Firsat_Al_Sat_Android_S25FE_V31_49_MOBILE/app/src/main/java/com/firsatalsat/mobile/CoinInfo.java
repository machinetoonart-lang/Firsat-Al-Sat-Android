package com.firsatalsat.mobile;

public final class CoinInfo {
    public final String symbol;
    public final String apiSymbol;
    public final int type;
    public final double last;
    public final double volume;
    public final double dailyPercent;
    public CoinInfo(String symbol,String apiSymbol,int type,double last,double volume,double dailyPercent){
        this.symbol=symbol;this.apiSymbol=apiSymbol;this.type=type;this.last=last;this.volume=volume;this.dailyPercent=dailyPercent;
    }
    @Override public String toString(){ return symbol; }
}
