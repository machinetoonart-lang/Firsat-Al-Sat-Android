package com.firsatalsat.mobile;

import java.util.*;

public final class MarketSnapshot {
    public final String exchange, symbol, timeframe, status;
    public final List<Candle> candles;
    public final IndicatorSet indicators;
    public final List<Signal> signals;
    public final double lastPrice;
    public final long updatedAtMs;
    public MarketSnapshot(String exchange,String symbol,String timeframe,String status,List<Candle> candles,IndicatorSet indicators,List<Signal> signals,double lastPrice,long updatedAtMs){
        this.exchange=exchange;this.symbol=symbol;this.timeframe=timeframe;this.status=status;this.candles=Collections.unmodifiableList(new ArrayList<>(candles));this.indicators=indicators;this.signals=Collections.unmodifiableList(new ArrayList<>(signals));this.lastPrice=lastPrice;this.updatedAtMs=updatedAtMs;
    }
}
