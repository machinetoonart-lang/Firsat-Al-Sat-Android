package com.firsatalsat.mobile;

import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.zip.GZIPInputStream;

public final class Net {
    private Net(){}
    public static String get(String url) throws IOException {
        IOException last=null;
        for(int attempt=0;attempt<3;attempt++){
            HttpURLConnection c=null;
            try{
                c=(HttpURLConnection)new URL(url).openConnection();
                c.setConnectTimeout(8000);c.setReadTimeout(8000);c.setRequestMethod("GET");
                c.setRequestProperty("Accept","application/json");c.setRequestProperty("Accept-Encoding","gzip");c.setRequestProperty("User-Agent","Firsat-Al-Sat-Android/1.0");
                int code=c.getResponseCode();
                if((code==429||code>=500)&&attempt<2){ try{Thread.sleep(220L*(attempt+1));}catch(InterruptedException ignored){} continue; }
                InputStream raw=(code>=200&&code<300)?c.getInputStream():c.getErrorStream();
                if(raw==null)throw new IOException("HTTP "+code);
                InputStream in="gzip".equalsIgnoreCase(c.getContentEncoding())?new GZIPInputStream(raw):raw;
                ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] buf=new byte[8192];int n;while((n=in.read(buf))>0)out.write(buf,0,n);
                String s=out.toString(StandardCharsets.UTF_8.name());
                if(code<200||code>=300)throw new IOException("HTTP "+code+": "+s);
                return s;
            }catch(IOException e){last=e;if(attempt<2){try{Thread.sleep(220L*(attempt+1));}catch(InterruptedException ignored){}}}
            finally{if(c!=null)c.disconnect();}
        }
        throw last!=null?last:new IOException("Bağlantı hatası");
    }
    public static String enc(String s){try{return URLEncoder.encode(s,"UTF-8");}catch(Exception e){return s;}}
}
