package com.firsatalsat.mobile;

import java.util.*;

public final class SignalEngine {
    private SignalEngine() {}

    public static List<Signal> historical(List<Candle> candles, IndicatorSet ind, int closedLastIndex) {
        ArrayList<Signal> out=new ArrayList<>();
        if(candles==null||candles.isEmpty()||closedLastIndex<0)return out;
        int n=Math.min(candles.size(),closedLastIndex+1);
        ArrayList<int[]> segs=new ArrayList<>();
        int active=0,start=-1;
        for(int i=0;i<n;i++){
            int d=ind.superTrendDir[i];
            if(d==0){ if(active!=0)segs.add(new int[]{active,start,i-1});active=0;start=-1;continue; }
            if(active==0){active=d;start=i;} else if(d!=active){segs.add(new int[]{active,start,i-1});active=d;start=i;}
        }
        if(active!=0)segs.add(new int[]{active,start,n-1});
        for(int k=0;k<segs.size();k++){
            int[] seg=segs.get(k); int dir=seg[0],a=seg[1],b=seg[2];
            int nextDir=(k+1<segs.size()?segs.get(k+1)[0]:0), nextStart=(k+1<segs.size()?segs.get(k+1)[1]:-1);
            if(dir<0 && nextDir>0 && nextStart>=0){
                int e=-1; double bestLow=Double.POSITIVE_INFINITY,bestHist=Double.POSITIVE_INFINITY;
                for(int j=a;j<=b;j++){
                    double h=ind.macdHist[j]; if(!Double.isFinite(h)||h>=0)continue; double lo=candles.get(j).low;
                    if(e<0||lo<bestLow-1e-12||(Math.abs(lo-bestLow)<1e-12 && (h<bestHist-1e-12||(Math.abs(h-bestHist)<1e-12&&j>e)))){e=j;bestLow=lo;bestHist=h;}
                }
                if(e>=0) out.add(new Signal(Signal.Type.BUY,e,nextStart,candles.get(e).timeSec,candles.get(nextStart).timeSec,candles.get(e).low,"Kırmızı trend bitti; negatif MACD barları içinde gerçek fiyat dibi"));
            } else if(dir>0){
                int maxI=-1; double maxH=-Double.MAX_VALUE; boolean emitted=false;
                for(int j=a;j<=b;j++){
                    double h=ind.macdHist[j]; if(!Double.isFinite(h))continue;
                    if(h>0 && (maxI<0||h>maxH+1e-12)){maxI=j;maxH=h;continue;}
                    if(maxI>=0&&j>maxI&&(h<=0||h<maxH-Math.max(Math.abs(maxH)*1e-10,1e-12))){
                        out.add(new Signal(Signal.Type.SELL,maxI,j,candles.get(maxI).timeSec,candles.get(j).timeSec,candles.get(maxI).high,"Yeşil trendde en yüksek pozitif MACD; ilk zayıflama teyidi")); emitted=true; break;
                    }
                }
                if(!emitted&&maxI>=0&&nextDir<0&&nextStart>=0){
                    out.add(new Signal(Signal.Type.SELL,maxI,nextStart,candles.get(maxI).timeSec,candles.get(nextStart).timeSec,candles.get(maxI).high,"Yeşil trend bitişi; en yüksek pozitif MACD"));
                }
            }
        }
        out.sort(Comparator.comparingLong(s->s.confirmTimeSec)); return out;
    }

    public static Signal newlyConfirmed(List<Candle> candles, IndicatorSet ind, int closedLastIndex) {
        List<Signal> all=historical(candles,ind,closedLastIndex); if(all.isEmpty())return null; Signal s=all.get(all.size()-1); return s.confirmIndex==closedLastIndex?s:null;
    }
}
