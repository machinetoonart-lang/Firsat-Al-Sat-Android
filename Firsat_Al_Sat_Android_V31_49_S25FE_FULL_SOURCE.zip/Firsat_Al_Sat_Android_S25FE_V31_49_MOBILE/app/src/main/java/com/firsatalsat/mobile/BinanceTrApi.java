package com.firsatalsat.mobile;

import org.json.*;
import java.util.*;

public final class BinanceTrApi implements MarketApi {
    private static final String SYMBOLS="https://www.binance.tr/open/v1/common/symbols";
    private static final String MAIN="https://api.binance.me";
    private static final String NEXT="https://cloudme-tr.2meta.app";
    private volatile List<CoinInfo> cached=new ArrayList<>();

    private static String clean(String s){return (s==null?"":s.toUpperCase(Locale.ROOT).replace("_","").replace("/","").replace("-","").replace(" ",""));}
    private static double num(Object o){try{return Double.parseDouble(String.valueOf(o));}catch(Exception e){return 0;}}
    private static JSONObject dataObj(JSONObject root){ Object d=root.opt("data"); return d instanceof JSONObject?(JSONObject)d:root; }
    private static JSONArray dataArray(JSONObject root){ Object d=root.opt("data"); if(d instanceof JSONArray)return (JSONArray)d; if(d instanceof JSONObject){Object l=((JSONObject)d).opt("list");if(l instanceof JSONArray)return (JSONArray)l;} Object l=root.opt("list");return l instanceof JSONArray?(JSONArray)l:new JSONArray(); }

    @Override public List<CoinInfo> coins() throws Exception {
        JSONObject root=new JSONObject(Net.get(SYMBOLS)); JSONArray arr=dataArray(root);
        HashMap<String,JSONObject> meta=new HashMap<>();
        for(int i=0;i<arr.length();i++){JSONObject x=arr.optJSONObject(i);if(x==null)continue;if(x.optInt("spotTradingEnable",1)!=1)continue;String quote=x.optString("quoteAsset","");if(!"TRY".equalsIgnoreCase(quote))continue;String raw=x.optString("symbol",x.optString("baseAsset","")+quote);meta.put(clean(raw),x);}
        HashMap<String,JSONObject> tick=new HashMap<>();
        try{ Object obj=new JSONTokener(Net.get(MAIN+"/api/v3/ticker/24hr")).nextValue(); JSONArray ta=obj instanceof JSONArray?(JSONArray)obj:new JSONArray(); for(int i=0;i<ta.length();i++){JSONObject t=ta.optJSONObject(i);if(t!=null)tick.put(clean(t.optString("symbol")),t);} }catch(Exception ignored){}
        ArrayList<CoinInfo> out=new ArrayList<>();
        for(Map.Entry<String,JSONObject> e:meta.entrySet()){
            JSONObject m=e.getValue(),t=tick.get(e.getKey());int type=m.optInt("type",1);String raw=m.optString("symbol",e.getKey());String api=type==1?e.getKey():raw;
            double last=t==null?0:num(t.opt("lastPrice")),vol=t==null?0:num(t.opt("volume")),pct=t==null?0:num(t.opt("priceChangePercent"));
            out.add(new CoinInfo(e.getKey(),api,type,last,vol,pct));
        }
        out.sort((a,b)->Double.compare(b.volume,a.volume)); cached=out; return out;
    }
    private String base(CoinInfo c){return c.type==1?MAIN:NEXT;}
    private static String interval(String tf){switch(tf){case"5dk":return"5m";case"15dk":return"15m";case"1s":return"1h";case"4s":return"4h";case"1g":return"1d";default:return"1m";}}
    @Override public List<Candle> candles(CoinInfo c,String timeframe,int limit) throws Exception {
        String u=base(c)+"/api/v1/klines?symbol="+Net.enc(c.apiSymbol)+"&interval="+interval(timeframe)+"&limit="+Math.max(60,Math.min(1000,limit));
        Object obj=new JSONTokener(Net.get(u)).nextValue(); JSONArray arr;
        if(obj instanceof JSONArray)arr=(JSONArray)obj; else if(obj instanceof JSONObject){Object d=((JSONObject)obj).opt("data"); if(d instanceof JSONObject)d=((JSONObject)d).opt("list"); arr=d instanceof JSONArray?(JSONArray)d:new JSONArray();} else arr=new JSONArray();
        ArrayList<Candle> out=new ArrayList<>();
        for(int i=0;i<arr.length();i++){JSONArray r=arr.optJSONArray(i);if(r==null||r.length()<6)continue;try{long ts=(long)num(r.opt(0))/1000L;double o=num(r.opt(1)),h=num(r.opt(2)),l=num(r.opt(3)),cl=num(r.opt(4)),v=num(r.opt(5));if(o>0&&h>0&&l>0&&cl>0&&h>=Math.max(o,cl)&&l<=Math.min(o,cl))out.add(new Candle(ts,o,h,l,cl,v));}catch(Exception ignored){}}
        if(out.isEmpty())throw new Exception(c.symbol+" Binance TR Kline boş"); return out;
    }
    @Override public double lastPrice(CoinInfo c) throws Exception {
        try{ Object obj=new JSONTokener(Net.get(base(c)+"/api/v3/ticker/price?symbol="+Net.enc(c.apiSymbol))).nextValue(); if(obj instanceof JSONObject)return num(((JSONObject)obj).opt("price")); }catch(Exception ignored){}
        List<Candle> cs=candles(c,"1dk",2);return cs.get(cs.size()-1).close;
    }
}
