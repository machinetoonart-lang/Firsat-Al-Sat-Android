package com.firsatalsat.mobile;

import java.util.*;

public interface MarketApi {
    List<CoinInfo> coins() throws Exception;
    List<Candle> candles(CoinInfo coin,String timeframe,int limit) throws Exception;
    double lastPrice(CoinInfo coin) throws Exception;
}
