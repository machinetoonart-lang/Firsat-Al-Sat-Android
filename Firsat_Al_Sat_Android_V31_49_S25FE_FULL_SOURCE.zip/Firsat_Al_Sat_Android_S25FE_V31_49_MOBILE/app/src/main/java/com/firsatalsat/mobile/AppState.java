package com.firsatalsat.mobile;
import java.util.*;import java.util.concurrent.*;
public final class AppState {
  public interface Listener{void onState();}
  public static volatile MarketSnapshot snapshot;
  public static volatile List<CoinInfo> coins=Collections.emptyList();
  public static volatile String error="";
  private static final CopyOnWriteArrayList<Listener> ls=new CopyOnWriteArrayList<>();
  public static void add(Listener l){ls.addIfAbsent(l);} public static void remove(Listener l){ls.remove(l);}
  public static void fire(){for(Listener l:ls)try{l.onState();}catch(Exception ignored){}}
}
