package com.firsatalsat.mobile;

import org.json.*;
import java.util.*;

public final class BtcTurkApi implements MarketApi {
    private static final String API="https://api.btcturk.com";
    private static final String GRAPH="https://graph-api.btcturk.com";
    private static double num(Object o){try{return Double.parseDouble(String.valueOf(o));}catch(Exception e){return 0;}}
    private static String clean(String s){return (s==null?"":s.toUpperCase(Locale.ROOT).replace("_","").replace("/","").replace("-","").replace(" ",""));}
    @Override public List<CoinInfo> coins() throws Exception {
        JSONObject root=new JSONObject(Net.get(API+"/api/v2/ticker"));JSONArray a=root.optJSONArray("data");if(a==null)throw new Exception("BtcTurk ticker boş");ArrayList<CoinInfo> out=new ArrayList<>();
        for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);if(x==null)continue;String s=clean(x.optString("pair",x.optString("pairNormalized","")));if(!s.endsWith("TRY"))continue;out.add(new CoinInfo(s,s,1,num(x.opt("last")),num(x.opt("volume")),num(x.opt("dailyPercent"))));}
        out.sort((x,y)->Double.compare(y.volume,x.volume));return out;
    }
    private static int resolution(String tf){switch(tf){case"15dk":return 15;case"1s":return 60;case"4s":return 240;default:return 1;}}
    private static int tfSec(String tf){switch(tf){case"15dk":return 900;case"1s":return 3600;case"4s":return 14400;case"1g":return 86400;default:return 60;}}
    @Override public List<Candle> candles(CoinInfo c,String tf,int limit) throws Exception {
        int sec=tfSec(tf),to=(int)(System.currentTimeMillis()/1000L);to=(to/sec)*sec;int from=to-Math.max(60,limit)*sec;
        if("5dk".equals(tf)){List<Candle> one=candles(c,"1dk",Math.max(300,limit*5+10));return aggregate(one,300,limit);}
        if("1g".equals(tf)){ // graph api accepts textual 1 d in desktop; URL encode space
            String u=GRAPH+"/v1/klines/history?symbol="+Net.enc(c.symbol)+"&resolution="+Net.enc("1 d")+"&from="+from+"&to="+to;return parseHistory(Net.get(u),c.symbol,limit);
        }
        String u=GRAPH+"/v1/klines/history?symbol="+Net.enc(c.symbol)+"&resolution="+resolution(tf)+"&from="+from+"&to="+to;
        return parseHistory(Net.get(u),c.symbol,limit);
    }
    private List<Candle> parseHistory(String js,String symbol,int limit)throws Exception{
        JSONObject r=new JSONObject(js);if(!"ok".equalsIgnoreCase(r.optString("s")))throw new Exception(symbol+" BtcTurk Kline yok");JSONArray t=r.optJSONArray("t"),o=r.optJSONArray("o"),h=r.optJSONArray("h"),l=r.optJSONArray("l"),c=r.optJSONArray("c"),v=r.optJSONArray("v");if(t==null||o==null||h==null||l==null||c==null||v==null)throw new Exception("BtcTurk Kline biçimi");ArrayList<Candle> out=new ArrayList<>();int start=Math.max(0,t.length()-limit);for(int i=start;i<t.length();i++){double op=num(o.opt(i)),hi=num(h.opt(i)),lo=num(l.opt(i)),cl=num(c.opt(i)),vo=num(v.opt(i));long ts=(long)num(t.opt(i));if(ts>10_000_000_000L)ts/=1000; if(op>0&&hi>0&&lo>0&&cl>0)out.add(new Candle(ts,op,hi,lo,cl,vo));}return out;
    }
    private List<Candle> aggregate(List<Candle> x,int bucket,int limit){LinkedHashMap<Long,double[]> m=new LinkedHashMap<>();for(Candle c:x){long k=(c.timeSec/bucket)*bucket;double[] a=m.get(k);if(a==null){a=new double[]{c.open,c.high,c.low,c.close,c.volume};m.put(k,a);}else{a[1]=Math.max(a[1],c.high);a[2]=Math.min(a[2],c.low);a[3]=c.close;a[4]+=c.volume;}}ArrayList<Candle> out=new ArrayList<>();for(Map.Entry<Long,double[]>e:m.entrySet()){double[]a=e.getValue();out.add(new Candle(e.getKey(),a[0],a[1],a[2],a[3],a[4]));}return out.subList(Math.max(0,out.size()-limit),out.size());}
    @Override public double lastPrice(CoinInfo c)throws Exception{JSONObject r=new JSONObject(Net.get(API+"/api/v2/ticker?pairSymbol="+Net.enc(c.symbol)));JSONArray a=r.optJSONArray("data");return a!=null&&a.length()>0?num(a.getJSONObject(0).opt("last")):0;}
}
