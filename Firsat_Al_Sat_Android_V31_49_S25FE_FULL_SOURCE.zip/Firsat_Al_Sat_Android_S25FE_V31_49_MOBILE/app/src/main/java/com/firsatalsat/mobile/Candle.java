package com.firsatalsat.mobile;

public final class Candle {
    public final long timeSec;
    public final double open, high, low, close, volume;
    public Candle(long timeSec, double open, double high, double low, double close, double volume) {
        this.timeSec = timeSec; this.open = open; this.high = high; this.low = low; this.close = close; this.volume = volume;
    }
}
