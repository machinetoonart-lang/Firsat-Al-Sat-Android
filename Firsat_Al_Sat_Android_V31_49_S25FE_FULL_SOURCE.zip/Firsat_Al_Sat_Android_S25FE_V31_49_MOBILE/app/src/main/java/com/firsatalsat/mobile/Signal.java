package com.firsatalsat.mobile;

public final class Signal {
    public enum Type { BUY, SELL }
    public final Type type;
    public final int targetIndex;
    public final int confirmIndex;
    public final long targetTimeSec;
    public final long confirmTimeSec;
    public final double targetPrice;
    public final String reason;
    public Signal(Type type, int targetIndex, int confirmIndex, long targetTimeSec, long confirmTimeSec, double targetPrice, String reason) {
        this.type = type; this.targetIndex = targetIndex; this.confirmIndex = confirmIndex;
        this.targetTimeSec = targetTimeSec; this.confirmTimeSec = confirmTimeSec; this.targetPrice = targetPrice; this.reason = reason;
    }
    public String id(String exchange, String symbol) {
        return exchange + ":" + symbol + ":" + type + ":" + confirmTimeSec + ":" + targetTimeSec;
    }
}
