FIRSAT AL SAT — ANDROID V31.49 MOBILE / SAMSUNG S25 FE

Bu proje masaüstü V31.49 karar mantığının Android'e yerel Java sürümüdür.

ÖZELLİKLER
- Samsung S25 FE dahil Android telefonlarda dikey + yatay kullanım.
- Binance TR / BtcTurk seçimi, TRY coin listesi ve arama.
- 1dk, 5dk, 15dk, 1s, 4s, 1g.
- Gerçek OHLC mum, hacim + SMA9, Bollinger 20/2, SuperTrend 10/3.
- MACD 12/26/9: koyu yeşil / açık yeşil / kırmızı / açık kırmızı + mavi MACD + turuncu Signal.
- Stoch RSI 14/14/3/3.
- Kesin AL/SAT kutuları.
- Katı karar kanunu:
  AL = kırmızı SuperTrend segmenti bittiğinde, segmentte negatif MACD barları içinde gerçek fiyatı en düşük mum.
  SAT = yeşil segmentte en yüksek pozitif MACD barı, ilk zayıflama kapalı mumuyla teyit.
  Diğer tüm durumlar = BEKLE.
- TL'DEYİM / COİNDEYİM manuel pozisyon kilidi; uygulama otomatik taraf değiştirmez.
- Aynı pozisyon döngüsünde tek ses+titreşim+Android bildirimi.
- Ön plan servisiyle başka uygulamaya geçince izleme sürer.
- Su terazileri dikey/yatay ekranda çalışır ve gizle/göster durumu hatırlanır.

VERİ KAYNAĞI
- Binance TR mumları: resmi Kline REST verisi. OHLC başka kaynaktan yeniden üretilmez.
- BtcTurk: graph-api Kline.

SÜRÜM
versionCode: 314901
versionName: 31.49-mobile-1

APK DERLEME
Android Studio ile açıp Build > Build APK(s) kullanılabilir.
GitHub Actions dosyası da eklenmiştir: .github/workflows/build-apk.yml
Çıktı: app/build/outputs/apk/debug/app-debug.apk

Not: Samsung telefonda APK'ya ilk kez dokunduğunuzda, dosyayı açan uygulama için "Bilinmeyen uygulamaları yükle" izni istenebilir.
